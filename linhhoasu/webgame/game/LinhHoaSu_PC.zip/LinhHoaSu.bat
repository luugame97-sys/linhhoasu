@echo off
setlocal
set GAME_URL=https://linhhoasu.lol/
set PROFILE_DIR=%LOCALAPPDATA%\LinhHoaSu_PC

:: 1. Try Google Chrome
if exist "%ProgramFiles%\Google\Chrome\Application\chrome.exe" (
    start "" "%ProgramFiles%\Google\Chrome\Application\chrome.exe" --app="%GAME_URL%" --user-data-dir="%PROFILE_DIR%" --window-size=1280,750
    exit /b
)
if exist "%ProgramFiles(x86)%\Google\Chrome\Application\chrome.exe" (
    start "" "%ProgramFiles(x86)%\Google\Chrome\Application\chrome.exe" --app="%GAME_URL%" --user-data-dir="%PROFILE_DIR%" --window-size=1280,750
    exit /b
)
if exist "%LOCALAPPDATA%\Google\Chrome\Application\chrome.exe" (
    start "" "%LOCALAPPDATA%\Google\Chrome\Application\chrome.exe" --app="%GAME_URL%" --user-data-dir="%PROFILE_DIR%" --window-size=1280,750
    exit /b
)

:: 2. Try Microsoft Edge (Built-in Windows 10/11)
if exist "%ProgramFiles(x86)%\Microsoft\Edge\Application\msedge.exe" (
    start "" "%ProgramFiles(x86)%\Microsoft\Edge\Application\msedge.exe" --app="%GAME_URL%" --user-data-dir="%PROFILE_DIR%" --window-size=1280,750
    exit /b
)
if exist "%ProgramFiles%\Microsoft\Edge\Application\msedge.exe" (
    start "" "%ProgramFiles%\Microsoft\Edge\Application\msedge.exe" --app="%GAME_URL%" --user-data-dir="%PROFILE_DIR%" --window-size=1280,750
    exit /b
)
if exist "%LOCALAPPDATA%\Microsoft\Edge\Application\msedge.exe" (
    start "" "%LOCALAPPDATA%\Microsoft\Edge\Application\msedge.exe" --app="%GAME_URL%" --user-data-dir="%PROFILE_DIR%" --window-size=1280,750
    exit /b
)

:: 3. Try CocCoc
if exist "%LOCALAPPDATA%\CocCoc\Browser\Application\browser.exe" (
    start "" "%LOCALAPPDATA%\CocCoc\Browser\Application\browser.exe" --app="%GAME_URL%" --user-data-dir="%PROFILE_DIR%" --window-size=1280,750
    exit /b
)

:: 4. Fallback to default browser
start "" "%GAME_URL%"
