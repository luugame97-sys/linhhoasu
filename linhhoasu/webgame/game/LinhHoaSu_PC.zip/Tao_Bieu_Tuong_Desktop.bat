@echo off
chcp 65001 >nul
echo ====================================================
echo    ĐANG TẠO PHÍM TẮT LINH HỌA SƯ RA MÀN HÌNH DESKTOP
echo ====================================================
echo.
set "SCRIPT_DIR=%~dp0"
set "EXE_PATH=%SCRIPT_DIR%LinhHoaSu.exe"
powershell -NoProfile -ExecutionPolicy Bypass -Command "$ws = New-Object -ComObject WScript.Shell; $s = $ws.CreateShortcut([System.IO.Path]::Combine([Environment]::GetFolderPath('Desktop'), 'Linh Họa Sư.lnk')); $s.TargetPath = '%EXE_PATH%'; $s.WorkingDirectory = '%SCRIPT_DIR%'; $s.Description = 'Linh Họa Sư - Game Tu Tiên Huyền Ảo'; $s.Save()"
echo [THÀNH CÔNG] Đã tạo biểu tượng Linh Họa Sư ngoài Desktop!
echo Bây giờ bạn có thể nhấp đúp vào biểu tượng trên Desktop để vào game.
echo.
pause
